import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "CAM Focus Dashboard",
  description: "Daily partner focus for Business Capital and Customer Token Vault.",
  other: {
    "codex-preview": "development",
  },
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
